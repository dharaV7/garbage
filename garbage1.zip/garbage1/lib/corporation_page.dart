import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:garbage1/main.dart';


class CorporationPage extends StatefulWidget {
  @override
  _CorporationPageState createState() => _CorporationPageState();
}

class _CorporationPageState extends State<CorporationPage> {

  void _logout() async {
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => LoginPage())); // Return to the login screen or another appropriate screen
    } catch (e) {
      print("Error during logout: $e");
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Corporation Page"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              _logout(); // Call the logout function when the button is pressed
            },
          ),
        ],
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection("tickets").snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }

          List<DocumentSnapshot> ticketDocuments = snapshot.data!.docs;

          return ListView.builder(
            itemCount: ticketDocuments.length,
            itemBuilder: (context, index) {
              final ticketData = ticketDocuments[index].data() as Map<String, dynamic>;
              final name = ticketData["name"];
              final issue = ticketData["issue"];
              final location = ticketData["location"];
              final isResolved = ticketData["resolved"] ?? false; // Read the "resolved" field

              return Card(
                elevation: 3.0,
                margin: EdgeInsets.all(10.0),
                color: isResolved ? Colors.lightBlue : Colors.white, // Set card color based on "resolved" field
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("$name's Issue"),
                          SizedBox(height: 8),
                          Text("Issue: $issue"),
                          SizedBox(height: 8),
                          Text("Location: $location"),
                        ],
                      ),
                    ),
                    Divider(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        if (!isResolved)
                          DropdownButton<String>(
                            items: ["Mark as Resolved"].map((String option) {
                              return DropdownMenuItem<String>(
                                value: option,
                                child: Text(option),
                              );
                            }).toList(),
                            onChanged: (String? value) {
                              if (value == "Mark as Resolved") {
                                // Mark the issue as resolved in Firestore
                                FirebaseFirestore.instance
                                    .collection("tickets")
                                    .doc(ticketDocuments[index].id)
                                    .update({"resolved": true});

                                // The card color will change automatically upon the next data snapshot
                              }
                            },
                          ),
                      ],
                    ),
                    if (isResolved)
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Issue Resolved",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

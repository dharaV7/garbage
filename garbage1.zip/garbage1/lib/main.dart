import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'general_people_page.dart';
import 'corporation_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if(kIsWeb){
    await Firebase.initializeApp(options: FirebaseOptions(apiKey: "AIzaSyC_DAw6l4GnZvkddUKWYkGNsHBmn7NTl94", appId: "1:242559790769:web:23d81563bb56135d573c90", messagingSenderId: "242559790769", projectId: "garbage1-bc60c"));
  }
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String _selectedRole = "Corporation Official";
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  Future<void> _showErrorDialog() async {
  await showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Error"),
        content: Text("Enter valid username/password."),
        actions: <Widget>[
          TextButton(
            child: Text("OK"),
            onPressed: () {
              Navigator.of(context).pop(); // Close the dialog
            },
          ),
        ],
      );
    },
  );
}


 Future<void> _login() async {
  final username = _usernameController.text;
  final password = _passwordController.text;

  try {
    final firebaseAuth = FirebaseAuth.instance;
    final firebaseUser = await firebaseAuth.signInWithEmailAndPassword(
      email: username, // Use the username as the email
      password: password,
    );

    // Check if authentication was successful
    if (firebaseUser != null) {
      // Fetch additional user data from Firestore
      final firestore = FirebaseFirestore.instance;
      final userDocument = await firestore.collection("users").doc(username).get();

      if (userDocument.exists) {
        // User data found, retrieve the role
        final role = userDocument.data()!["role"];

        if (role == "General People") {
        // Navigate to the General People page upon successful login
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => GeneralPeoplePage(
            username: username,
        password: password,
        role: role,
          )),
        );
      }
      if (role == "Corporation Official") {
        // Navigate to the Corporation Official page
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => CorporationPage()),
        );
      } 
       else {
        // Handle other roles or scenarios
        // ...
      }

        // You can navigate to the next page or perform other actions here
      } else {
        // User data not found, handle the error
        _showErrorDialog();
      }
    } else {
      // Authentication failed, handle the error
      _showErrorDialog();
    }
  } catch (e) {
    // Handle authentication errors
    _showErrorDialog();
  }
}




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        title: Text(
          "Login",
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
      ),
      body: Center(
        child: Card(
          margin: EdgeInsets.symmetric(horizontal: 16),
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                DropdownButtonFormField<String>(
                  value: _selectedRole,
                  onChanged: (value) {
                    setState(() {
                      _selectedRole = value!;
                    });
                  },
                  items: ["Corporation Official", "General People"]
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  decoration: InputDecoration(
                    labelText: "Role",
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _usernameController,
                  decoration: InputDecoration(
                    labelText: "Username",
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                TextFormField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: "Password",
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                ElevatedButton(
    onPressed: _login,
    child: Text("Login"),
    style: ElevatedButton.styleFrom(
      padding: EdgeInsets.symmetric(vertical: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
    ),
  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

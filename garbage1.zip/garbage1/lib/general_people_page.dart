import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:garbage1/main.dart';

class GeneralPeoplePage extends StatelessWidget {
  final String username;
  final String password;
  final String role;
  

  GeneralPeoplePage({required this.username, required this.password, required this.role});

  void _logout(BuildContext context) async {
    try {
      await FirebaseAuth.instance.signOut();
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => LoginPage())); // Return to the login screen
    } catch (e) {
      print("Error during logout: $e");
    }
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _issueController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();

  void _submitForm(BuildContext context) async {
    if (_formKey.currentState!.validate()) {
      final name = _nameController.text;
      final issue = _issueController.text;
      final location = _locationController.text;

      try {
        final user = FirebaseAuth.instance.currentUser;
        if (user != null) {
          final userData = {
            "name": name,
            "issue": issue,
            "location": location,
            "userId": user.uid,
          };

          await FirebaseFirestore.instance.collection("tickets").add(userData);

          // Show a success pop-up
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text("Success"),
                content: Text("Your issue has been sent."),
                actions: <Widget>[
                  TextButton(
                    child: Text("OK"),
                    onPressed: () {
                      Navigator.of(context).pop(); // Close the dialog
                    },
                  ),
                ],
              );
            },
          );
        }
      } catch (error) {
        print("Error sending issue: $error");
      }
    } else {
      // Show an error pop-up
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Error"),
            content: Text("Enter all details."),
            actions: <Widget>[
              TextButton(
                child: Text("OK"),
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                },
              ),
            ],
          );
        },
      );
    }
  }
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("General People Page"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              _logout(context); // Call the logout function when the button is pressed
            },
          ),
        ],
      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(16.0),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.black),
            borderRadius: BorderRadius.circular(16.0),
          ),
          child: ListView(
            shrinkWrap: true,
            children: [
              Text(
                "Username: $username",
                style: TextStyle(fontSize: 20.0),
              ),
              Text(
                "Password: $password",
                style: TextStyle(fontSize: 20.0),
              ),
              Text(
                "Role: $role",
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(height: 20),
              Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      "Submit a Query",
                      style: TextStyle(fontSize: 20.0),
                    ),
                    TextFormField(
                      controller: _nameController,
                      decoration: InputDecoration(
                        labelText: "Name",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Please enter your name.";
                        }
                        return null;
                      },
                    ),
                    TextFormField(
                      controller: _issueController,
                      decoration: InputDecoration(
                        labelText: "Issue",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Please enter the issue.";
                        }
                        return null;
                      },
                    ),
                    TextFormField(
                      controller: _locationController,
                      decoration: InputDecoration(
                        labelText: "Location",
                      ),
                      validator: (value) {
                        if (value!.isEmpty) {
                          return "Please enter the location.";
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () => _submitForm(context),
                      child: Text("Submit", style: TextStyle(fontSize: 20.0)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
